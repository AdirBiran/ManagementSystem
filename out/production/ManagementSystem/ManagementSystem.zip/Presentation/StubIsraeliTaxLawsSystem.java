package Presentation;

public class StubIsraeliTaxLawsSystem {



    public boolean connect(boolean flag) {
        return flag;
    }
}
