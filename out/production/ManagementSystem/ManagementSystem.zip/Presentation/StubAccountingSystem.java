package Presentation;

public class StubAccountingSystem {



    public boolean connect(boolean flag) {
        return flag;
    }
}
