package Domain;

public class MailSender {

    public static boolean send(String mail, String message){
        //send mail to user
        return true;
    }
}
