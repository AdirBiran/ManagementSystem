package Domain;

public interface Role {
}
