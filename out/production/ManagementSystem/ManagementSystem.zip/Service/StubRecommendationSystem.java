package Service;

public class StubRecommendationSystem {

    public StubRecommendationSystem() {
    }

    public boolean connect(){
        return true;
    }

    public boolean trainModel(){
        return true;
    }
}
